#pragma once
#include "Forms.h"

#include "f4se/PapyrusVM.h"
#include "f4se/PapyrusNativeFunctions.h"

namespace Papyrus {
    bool Init(VirtualMachine* VM);
}