#pragma once

#include "f4se_globals/Globals.h"

namespace ObScript {
    bool Hook_Commit();
}