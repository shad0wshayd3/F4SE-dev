#include "Papyrus.h"

bool Papyrus::Init(VirtualMachine* VM) {
    // VM->RegisterFunction(new NativeFunction0<StaticFunctionTag, void>
    //     ("ExampleFunction",  PAPYRUS_SCRIPT_NAME,    ExampleFunctionImpl,    VM));

    return true;
}