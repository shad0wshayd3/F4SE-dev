#pragma once
#include "Forms.h"

namespace Serialize {
    bool Hook_Commit();
}